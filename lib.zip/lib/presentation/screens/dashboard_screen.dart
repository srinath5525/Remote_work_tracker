import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../features/tasks/task_controller.dart';
import '../../features/tasks/task_model.dart';
import 'dart:collection';
import 'package:flutter/rendering.dart';
import 'dart:ui';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  List<String> getLast6Months() {
    final now = DateTime.now();
    List<String> months = [];
    for (int i = 5; i >= 0; i--) {
      final date = DateTime(now.year, now.month - i);
      months.add(_monthName(date.month));
    }
    return months;
  }

  String _monthName(int month) {
    const months = [
      '',
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return months[month];
  }

  @override
  Widget build(BuildContext context) {
    final months = getLast6Months();
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/background.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Dashboard', style: TextStyle(color: Colors.white)),
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        backgroundColor: Colors.transparent,
        body: StreamBuilder<List<TaskModel>>(
          stream: TaskController.getTasks(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final tasks = snapshot.data!;
            final completed = tasks.where((t) => t.isDone).toList();
            final overdue = tasks
                .where((t) => !t.isDone && t.dueDate.isBefore(DateTime.now()))
                .toList();
            final uncompleted = tasks
                .where((t) => !t.isDone && !t.dueDate.isBefore(DateTime.now()))
                .toList();

            // Prepare data for the last 6 months
            final now = DateTime.now();
            final Map<String, int> monthToCount = LinkedHashMap();
            final List<DateTime> monthDates = List.generate(
              6,
              (i) => DateTime(now.year, now.month - 5 + i),
            );
            for (final date in monthDates) {
              final key = _monthName(date.month);
              monthToCount[key] = 0;
            }
            for (final task in completed) {
              if (task.completedAt == null) continue;
              final completedMonth = DateTime(
                task.completedAt!.year,
                task.completedAt!.month,
              );
              for (final date in monthDates) {
                if (date.year == completedMonth.year &&
                    date.month == completedMonth.month) {
                  final key = _monthName(date.month);
                  monthToCount[key] = (monthToCount[key] ?? 0) + 1;
                  break;
                }
              }
            }

            return SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                child: Column(
                  children: [
                    // Summary Row
                    ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(color: Colors.white, width: 3),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 24,
                              horizontal: 16,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _statTile(
                                  'Completed',
                                  completed.length,
                                  Colors.green,
                                ),
                                _statTile(
                                  'Uncompleted',
                                  uncompleted.length,
                                  Colors.orange,
                                ),
                                _statTile(
                                  'Overdue',
                                  overdue.length,
                                  Colors.red,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    // Chart Card
                    Card(
                      color: Colors.black,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: SizedBox(
                          height: 260,
                          child: BarChart(
                            BarChartData(
                              alignment: BarChartAlignment.spaceAround,
                              maxY:
                                  (monthToCount.values.isEmpty
                                          ? 5
                                          : (monthToCount.values.reduce(
                                                  (a, b) => a > b ? a : b,
                                                ) +
                                                2))
                                      .toDouble(),
                              minY: 0,
                              barTouchData: BarTouchData(enabled: true),
                              titlesData: FlTitlesData(
                                leftTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    interval: 1,
                                    getTitlesWidget: (value, meta) => Text(
                                      value.toInt().toString(),
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ),
                                ),
                                bottomTitles: AxisTitles(
                                  sideTitles: SideTitles(
                                    showTitles: true,
                                    getTitlesWidget: (value, meta) {
                                      final idx = value.toInt();
                                      if (idx < 0 || idx >= months.length)
                                        return const SizedBox.shrink();
                                      return Padding(
                                        padding: const EdgeInsets.only(top: 8),
                                        child: Text(
                                          months[idx],
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.white,
                                          ),
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                rightTitles: AxisTitles(
                                  sideTitles: SideTitles(showTitles: false),
                                ),
                                topTitles: AxisTitles(
                                  sideTitles: SideTitles(showTitles: false),
                                ),
                              ),
                              borderData: FlBorderData(
                                show: true,
                                border: Border.all(
                                  color: Colors.white,
                                  width: 2,
                                ),
                              ),
                              barGroups: List.generate(months.length, (i) {
                                final count = monthToCount[months[i]] ?? 0;
                                return BarChartGroupData(
                                  x: i,
                                  barRods: [
                                    BarChartRodData(
                                      toY: count.toDouble(),
                                      color: Colors.white,
                                      width: 24,
                                      borderRadius: BorderRadius.circular(8),
                                      backDrawRodData:
                                          BackgroundBarChartRodData(
                                            show: true,
                                            toY:
                                                (monthToCount.values.isEmpty
                                                        ? 5
                                                        : (monthToCount.values
                                                                  .reduce(
                                                                    (a, b) =>
                                                                        a > b
                                                                        ? a
                                                                        : b,
                                                                  ) +
                                                              2))
                                                    .toDouble(),
                                            color: Colors.white.withOpacity(
                                              0.08,
                                            ),
                                          ),
                                    ),
                                  ],
                                );
                              }),
                              gridData: FlGridData(show: false),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        floatingActionButton: FloatingActionButton(
          backgroundColor: Colors.white,
          onPressed: () {},
          child: const Icon(Icons.add, color: Color(0xFFB200B2)),
        ),
      ),
    );
  }

  Widget _statTile(String label, int value, Color color) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.8), width: 2),
            color: color.withOpacity(0.1),
          ),
          child: Text(
            '$value',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w900,
              color: color,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}
