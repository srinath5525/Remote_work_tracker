import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tzdata;

class LocalNotificationService {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    tzdata.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    const settings = InitializationSettings(android: android, iOS: ios);
    await _plugin.initialize(settings);
  }

  static Future<void> showLoginNotification(String userName) async {
    await _plugin.show(
      0,
      'Login Successful',
      'Welcome, $userName!',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'login_channel',
          'Login',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  static Future<void> showLogoutNotification(String userName) async {
    await _plugin.show(
      1,
      'Logout Successful',
      'Goodbye, $userName!',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'logout_channel',
          'Logout',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }

  static Future<void> scheduleRepeatingDeadlineNotifications({
    required int id,
    required String taskTitle,
    required DateTime deadline,
    bool notify = true,
  }) async {
    if (!notify) return;

    final now = DateTime.now();
    final start = deadline.subtract(const Duration(hours: 5));
    if (now.isAfter(deadline)) return;
    if (now.isAfter(start)) {
      // Already within 5 hours, start from now
      print(
        '⏰ Scheduling repeating notifications for "$taskTitle" every 30 min until $deadline',
      );
      await _scheduleRepeating(id, taskTitle, now, deadline);
    } else {
      // Schedule a one-time notification to trigger later
      print(
        '⏰ Scheduling one-time notification for "$taskTitle" at $start (5 hours before $deadline)',
      );
      await _plugin.zonedSchedule(
        id,
        'Task Reminder',
        'Your task "$taskTitle" is due in 5 hours!',
        tz.TZDateTime.from(start, tz.local),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'deadline_channel',
            'Task Deadlines',
            importance: Importance.max,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        payload: 'start_repeating',
      );
    }
  }

  static Future<void> _scheduleRepeating(
    int id,
    String taskTitle,
    DateTime from,
    DateTime deadline,
  ) async {
    DateTime next = from;
    int repeatId = id * 1000; // Unique base for this task
    while (next.isBefore(deadline)) {
      print('⏰ Scheduling notification for "$taskTitle" at $next');
      await _plugin.zonedSchedule(
        repeatId,
        'Task Reminder',
        'Your task "$taskTitle" is due at \\${deadline.hour}:\\${deadline.minute.toString().padLeft(2, '0')}',
        tz.TZDateTime.from(next, tz.local),
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'deadline_channel',
            'Task Deadlines',
            importance: Importance.max,
            priority: Priority.high,
          ),
          iOS: DarwinNotificationDetails(),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
      next = next.add(const Duration(minutes: 30));
      repeatId++;
    }
  }

  static Future<void> cancelTaskNotifications(int taskId) async {
    final baseId = taskId * 1000;
    for (int i = 0; i < 10; i++) {
      await _plugin.cancel(baseId + i);
    }
  }

  static Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }

  static Future<void> scheduleHealthReminders() async {
    // Drink water every hour
    await _plugin.periodicallyShow(
      10001,
      'Hydration Reminder',
      'Time to drink some water!',
      RepeatInterval.hourly,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'health_channel',
          'Health Reminders',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
    // Screen break every 2 hours (using hourly for demo, adjust as needed)
    await _plugin.periodicallyShow(
      10002,
      'Screen Break',
      'Look away from the screen for a few minutes!',
      RepeatInterval.hourly,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'health_channel',
          'Health Reminders',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  static Future<void> showTakeBreakNotification() async {
    await _plugin.show(
      20001,
      'Pomodoro Complete',
      'Great job! Time to take a break.',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'pomodoro_channel',
          'Pomodoro',
          importance: Importance.max,
          priority: Priority.high,
        ),
        iOS: DarwinNotificationDetails(),
      ),
    );
  }
}
