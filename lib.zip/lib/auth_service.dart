import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;

  static Stream<User?> get userStream => _auth.authStateChanges();

  static Future<void> signInWithGoogle() async {
    try {
      print('🔵 Starting Google sign-in');
      final GoogleSignIn googleSignIn = GoogleSignIn(
        // ✅ Set the clientId only for web
        clientId: kIsWeb
            ? '72265768543-27ie5mln5pd92vh6j6n736qv9oh1fl0k.apps.googleusercontent.com' // 🔁 Replace this with actual Web client ID
            : null,
      );

      final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
      if (googleUser == null) {
        print('🟡 Google sign-in aborted by user');
        return;
      }

      print('🟢 Google user selected: \\${googleUser.email}');
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      print('🟢 Got Google auth tokens');
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      await _auth.signInWithCredential(credential);
      print('✅ Firebase sign-in successful');
    } catch (e, stack) {
      print('🔴 Google sign-in error: $e');
      print(stack);
      rethrow;
    }
  }

  static Future<void> signOut() async {
    await _auth.signOut();
    await GoogleSignIn().signOut();
  }

  static User? get currentUser => _auth.currentUser;
}
