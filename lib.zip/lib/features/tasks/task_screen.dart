import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../auth_service.dart';
import '../../core/services/local_notification_service.dart';
import 'task_model.dart';
import 'task_controller.dart';
import 'add_task_form.dart';
import 'productivity_dashboard.dart';
import 'stopwatch_modal.dart';
import '../../presentation/screens/dashboard_screen.dart';
import 'package:flutter/rendering.dart';
import 'dart:ui';

enum TaskFilter { all, done, pending, today, overdue }

class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  TaskFilter _filter = TaskFilter.all;
  final ScrollController _scrollController = ScrollController();
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  String? _editingTaskId;
  final Map<String, TextEditingController> _titleControllers = {};
  final Map<String, TextEditingController> _descControllers = {};
  final Map<String, DateTime> _editDates = {};

  void _setFilter(TaskFilter filter) {
    setState(() {
      _filter = filter;
    });
  }

  Color _getPriorityColor(TaskPriority priority) {
    switch (priority) {
      case TaskPriority.low:
        return Colors.green;
      case TaskPriority.medium:
        return Colors.orange;
      case TaskPriority.high:
        return Colors.red;
    }
  }

  void _openAddTaskForm(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: AddTaskForm(
          onSave: (title, desc, date, priority) {
            final newTask = TaskModel(
              id: const Uuid().v4(),
              title: title,
              description: desc,
              dueDate: date,
              priority: priority,
            );
            print('🔥 Creating task: ${newTask.toMap()}');
            TaskController.addTask(newTask);
          },
        ),
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_filter) {
      case TaskFilter.all:
        return 'All Tasks';
      case TaskFilter.pending:
        return 'Pending Tasks';
      case TaskFilter.done:
        return 'Completed Tasks';
      case TaskFilter.today:
        return "Today's Tasks";
      case TaskFilter.overdue:
        return 'Overdue Tasks';
      default:
        return 'Your Tasks';
    }
  }

  @override
  Widget build(BuildContext context) {
    final Color backgroundColor = const Color(0xFFB200B2); // Vibrant purple
    final Color cardColor = const Color(0xFFF5E6FA); // Light lavender
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage('assets/background.jpg'),
          fit: BoxFit.cover,
        ),
      ),
      child: Stack(
        children: [
          Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              backgroundColor: Colors.transparent,
              elevation: 0,
              title: Text(_getAppBarTitle()),
              actions: [
                // Offline status indicator
                if (TaskController.isOffline)
                  Container(
                    margin: const EdgeInsets.only(right: 16),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.orange.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.orange, width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.wifi_off, size: 16, color: Colors.white),
                        const SizedBox(width: 4),
                        Text(
                          'Offline',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                // Pending sync indicator
                if (TaskController.pendingSyncCount > 0)
                  Container(
                    margin: const EdgeInsets.only(right: 16),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.blue.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.blue, width: 1),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.sync, size: 16, color: Colors.white),
                        const SizedBox(width: 4),
                        Text(
                          '${TaskController.pendingSyncCount}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            drawer: _buildUserDrawer(context),
            body: Column(
              children: [
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 8,
                  ),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(30),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 4,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: (value) {
                        setState(() {
                          _searchQuery = value;
                        });
                      },
                      decoration: InputDecoration(
                        hintText: 'Type Title to Search...',
                        border: InputBorder.none,
                        prefixIcon: Icon(Icons.search, color: Colors.grey),
                        contentPadding: const EdgeInsets.symmetric(
                          vertical: 16,
                        ),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 32, top: 4, bottom: 8),
                  child: _MainScreenFilterDropdown(
                    filter: _filter,
                    onChanged: (TaskFilter? newFilter) {
                      if (newFilter != null) {
                        setState(() {
                          _filter = newFilter;
                        });
                      }
                    },
                  ),
                ),
                Expanded(
                  child: Center(
                    child: StreamBuilder<List<TaskModel>>(
                      stream: TaskController.getTasks(),
                      builder: (context, snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.waiting) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        }

                        final allTasks = snapshot.data ?? [];

                        // 🧠 Apply Filter
                        final filteredTasks = allTasks
                            .where((task) {
                              final now = DateTime.now();
                              switch (_filter) {
                                case TaskFilter.done:
                                  return task.isDone;
                                case TaskFilter.pending:
                                  return !task.isDone;
                                case TaskFilter.today:
                                  return !task.isDone &&
                                      task.dueDate.year == now.year &&
                                      task.dueDate.month == now.month &&
                                      task.dueDate.day == now.day;
                                case TaskFilter.overdue:
                                  return !task.isDone &&
                                      task.dueDate.isBefore(DateTime.now());
                                case TaskFilter.all:
                                default:
                                  return true;
                              }
                            })
                            .where(
                              (task) => task.title.toLowerCase().contains(
                                _searchQuery.toLowerCase(),
                              ),
                            )
                            .toList();

                        // 🔄 Sort by completion status and dueDate
                        filteredTasks.sort((a, b) {
                          // First sort by completion status (incomplete tasks first)
                          if (a.isDone != b.isDone) {
                            return a.isDone
                                ? 1
                                : -1; // Completed tasks go to the end
                          }
                          // Then sort by dueDate for tasks with same completion status
                          return a.dueDate.compareTo(b.dueDate);
                        });

                        if (filteredTasks.isEmpty) {
                          return const Center(
                            child: Text(
                              "No tasks found.",
                              style: TextStyle(color: Colors.white),
                            ),
                          );
                        }

                        final PageController _pageController = PageController(
                          viewportFraction: 0.8,
                        );

                        return AnimatedBuilder(
                          animation: _pageController,
                          builder: (context, child) {
                            return PageView.builder(
                              controller: _pageController,
                              itemCount: filteredTasks.length,
                              itemBuilder: (context, index) {
                                double value = 1.0;
                                if (_pageController.position.haveDimensions) {
                                  num diff =
                                      (_pageController.page ??
                                          _pageController.initialPage) -
                                      index;
                                  value = diff.toDouble();
                                  num rawValue = (1 - (value.abs() * 0.2))
                                      .clamp(0.85, 1.0);
                                  value = rawValue.toDouble();
                                }
                                final task = filteredTasks[index];
                                final daysLeft = task.dueDate
                                    .difference(DateTime.now())
                                    .inDays;
                                final isEditing = _editingTaskId == task.id;
                                _titleControllers.putIfAbsent(
                                  task.id,
                                  () => TextEditingController(text: task.title),
                                );
                                _descControllers.putIfAbsent(
                                  task.id,
                                  () => TextEditingController(
                                    text: task.description,
                                  ),
                                );
                                _editDates.putIfAbsent(
                                  task.id,
                                  () => task.dueDate,
                                );
                                return Center(
                                  child: Opacity(
                                    opacity: task.isDone ? 0.5 : 1.0,
                                    child: Transform.translate(
                                      offset: const Offset(0, -10),
                                      child: Transform.scale(
                                        scale: value,
                                        child: ClipRRect(
                                          borderRadius: BorderRadius.circular(
                                            24,
                                          ),
                                          child: BackdropFilter(
                                            filter: ImageFilter.blur(
                                              sigmaX: 12,
                                              sigmaY: 12,
                                            ),
                                            child: Container(
                                              width:
                                                  MediaQuery.of(
                                                    context,
                                                  ).size.width *
                                                  0.85,
                                              height: 320,
                                              margin:
                                                  const EdgeInsets.symmetric(
                                                    vertical: 24,
                                                  ),
                                              decoration: BoxDecoration(
                                                color: Colors.white.withOpacity(
                                                  0.35,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(24),
                                                border: Border.all(
                                                  color: Colors.white,
                                                  width: 3,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                    color: Colors.black12,
                                                    blurRadius: 12,
                                                    offset: Offset(0, 6),
                                                  ),
                                                ],
                                              ),
                                              child: Stack(
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.fromLTRB(
                                                          20,
                                                          20,
                                                          20,
                                                          48,
                                                        ),
                                                    child: Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .start,
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Row(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                          children: [
                                                            Expanded(
                                                              child: isEditing
                                                                  ? TextField(
                                                                      controller:
                                                                          _titleControllers[task
                                                                              .id],
                                                                      decoration: const InputDecoration(
                                                                        border:
                                                                            InputBorder.none,
                                                                        hintText:
                                                                            'Title',
                                                                        hintStyle: TextStyle(
                                                                          fontWeight:
                                                                              FontWeight.bold,
                                                                          fontSize:
                                                                              20,
                                                                        ),
                                                                      ),
                                                                      style: const TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        fontSize:
                                                                            20,
                                                                      ),
                                                                    )
                                                                  : Text(
                                                                      task.title,
                                                                      style: const TextStyle(
                                                                        fontWeight:
                                                                            FontWeight.bold,
                                                                        fontSize:
                                                                            20,
                                                                      ),
                                                                    ),
                                                            ),
                                                            Checkbox(
                                                              value:
                                                                  task.isDone,
                                                              onChanged: (value) {
                                                                final updatedTask =
                                                                    task.copyWith(
                                                                      isDone:
                                                                          value ??
                                                                          false,
                                                                    );
                                                                TaskController.updateTask(
                                                                  updatedTask,
                                                                );
                                                              },
                                                            ),
                                                          ],
                                                        ),
                                                        const SizedBox(
                                                          height: 8,
                                                        ),
                                                        const Text(
                                                          'Description',
                                                          style: TextStyle(
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 16,
                                                          ),
                                                        ),
                                                        const SizedBox(
                                                          height: 2,
                                                        ),
                                                        isEditing
                                                            ? TextField(
                                                                controller:
                                                                    _descControllers[task
                                                                        .id],
                                                                maxLines: 3,
                                                                decoration: const InputDecoration(
                                                                  border:
                                                                      InputBorder
                                                                          .none,
                                                                  hintText:
                                                                      'Add Description...',
                                                                ),
                                                                style:
                                                                    const TextStyle(
                                                                      fontSize:
                                                                          15,
                                                                    ),
                                                              )
                                                            : Text(
                                                                task.description,
                                                                style:
                                                                    const TextStyle(
                                                                      fontSize:
                                                                          15,
                                                                    ),
                                                              ),
                                                        const SizedBox(
                                                          height: 16,
                                                        ),
                                                        isEditing
                                                            ? InkWell(
                                                                onTap: () async {
                                                                  final picked = await showDatePicker(
                                                                    context:
                                                                        context,
                                                                    initialDate:
                                                                        _editDates[task
                                                                            .id]!,
                                                                    firstDate:
                                                                        DateTime(
                                                                          2000,
                                                                        ),
                                                                    lastDate:
                                                                        DateTime(
                                                                          2100,
                                                                        ),
                                                                  );
                                                                  if (picked !=
                                                                      null) {
                                                                    setState(() {
                                                                      _editDates[task
                                                                              .id] =
                                                                          picked;
                                                                    });
                                                                  }
                                                                },
                                                                child: Row(
                                                                  children: [
                                                                    Text(
                                                                      '${_editDates[task.id]!.day.toString().padLeft(2, '0')}/${_editDates[task.id]!.month.toString().padLeft(2, '0')}/${_editDates[task.id]!.year}',
                                                                      style: const TextStyle(
                                                                        fontSize:
                                                                            15,
                                                                      ),
                                                                    ),
                                                                    const SizedBox(
                                                                      width: 8,
                                                                    ),
                                                                    const Icon(
                                                                      Icons
                                                                          .calendar_today,
                                                                      size: 18,
                                                                      color: Colors
                                                                          .deepPurple,
                                                                    ),
                                                                  ],
                                                                ),
                                                              )
                                                            : Text(
                                                                'Due on ${task.dueDate.day.toString().padLeft(2, '0')}/${task.dueDate.month.toString().padLeft(2, '0')}/${task.dueDate.year}',
                                                                style:
                                                                    const TextStyle(
                                                                      fontSize:
                                                                          15,
                                                                    ),
                                                              ),
                                                        const SizedBox(
                                                          height: 4,
                                                        ),
                                                        if (!isEditing)
                                                          RichText(
                                                            text: TextSpan(
                                                              style:
                                                                  const TextStyle(
                                                                    fontSize:
                                                                        15,
                                                                    color: Colors
                                                                        .black,
                                                                  ),
                                                              children: [
                                                                const TextSpan(
                                                                  text:
                                                                      'Due in ',
                                                                ),
                                                                TextSpan(
                                                                  text:
                                                                      '${daysLeft >= 0 ? daysLeft : 0} days',
                                                                  style: const TextStyle(
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .bold,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        const SizedBox(
                                                          height: 8,
                                                        ),
                                                        // Priority Display
                                                        Row(
                                                          children: [
                                                            Icon(
                                                              Icons
                                                                  .priority_high,
                                                              size: 18,
                                                              color:
                                                                  _getPriorityColor(
                                                                    task.priority,
                                                                  ),
                                                            ),
                                                            const SizedBox(
                                                              width: 6,
                                                            ),
                                                            Container(
                                                              padding:
                                                                  const EdgeInsets.symmetric(
                                                                    horizontal:
                                                                        12,
                                                                    vertical: 6,
                                                                  ),
                                                              decoration: BoxDecoration(
                                                                color:
                                                                    _getPriorityColor(
                                                                      task.priority,
                                                                    ).withOpacity(
                                                                      0.15,
                                                                    ),
                                                                borderRadius:
                                                                    BorderRadius.circular(
                                                                      16,
                                                                    ),
                                                                border: Border.all(
                                                                  color: _getPriorityColor(
                                                                    task.priority,
                                                                  ),
                                                                  width: 2,
                                                                ),
                                                                boxShadow: [
                                                                  BoxShadow(
                                                                    color: _getPriorityColor(
                                                                      task.priority,
                                                                    ).withOpacity(0.4),
                                                                    blurRadius:
                                                                        8,
                                                                    offset:
                                                                        const Offset(
                                                                          0,
                                                                          4,
                                                                        ),
                                                                    spreadRadius:
                                                                        1,
                                                                  ),
                                                                ],
                                                              ),
                                                              child: Row(
                                                                mainAxisSize:
                                                                    MainAxisSize
                                                                        .min,
                                                                children: [
                                                                  Text(
                                                                    'Priority: ',
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w800,
                                                                      color: _getPriorityColor(
                                                                        task.priority,
                                                                      ),
                                                                      shadows: [
                                                                        Shadow(
                                                                          color: Colors.black.withOpacity(
                                                                            0.3,
                                                                          ),
                                                                          blurRadius:
                                                                              2,
                                                                          offset: const Offset(
                                                                            1,
                                                                            1,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                  Text(
                                                                    task.priority
                                                                        .toString()
                                                                        .split(
                                                                          '.',
                                                                        )
                                                                        .last
                                                                        .toUpperCase(),
                                                                    style: TextStyle(
                                                                      fontSize:
                                                                          14,
                                                                      fontWeight:
                                                                          FontWeight
                                                                              .w900,
                                                                      color: _getPriorityColor(
                                                                        task.priority,
                                                                      ),
                                                                      shadows: [
                                                                        Shadow(
                                                                          color: Colors.black.withOpacity(
                                                                            0.4,
                                                                          ),
                                                                          blurRadius:
                                                                              3,
                                                                          offset: const Offset(
                                                                            1,
                                                                            1,
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Positioned(
                                                    bottom: 12,
                                                    left: 16,
                                                    child: IconButton(
                                                      icon: const Icon(
                                                        Icons.delete,
                                                        color: Colors.black87,
                                                      ),
                                                      onPressed: () =>
                                                          TaskController.deleteTask(
                                                            task.id,
                                                          ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    bottom: 12,
                                                    right: 16,
                                                    child: IconButton(
                                                      icon: Icon(
                                                        isEditing
                                                            ? Icons.check
                                                            : Icons.edit,
                                                        color: isEditing
                                                            ? Colors.green
                                                            : Colors.black87,
                                                      ),
                                                      onPressed: () {
                                                        if (isEditing) {
                                                          // Save changes
                                                          final updatedTask = task.copyWith(
                                                            title:
                                                                _titleControllers[task
                                                                        .id]!
                                                                    .text,
                                                            description:
                                                                _descControllers[task
                                                                        .id]!
                                                                    .text,
                                                            dueDate:
                                                                _editDates[task
                                                                    .id]!,
                                                          );
                                                          TaskController.updateTask(
                                                            updatedTask,
                                                          );
                                                          setState(() {
                                                            _editingTaskId =
                                                                null;
                                                          });
                                                        } else {
                                                          setState(() {
                                                            _editingTaskId =
                                                                task.id;
                                                          });
                                                        }
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
            floatingActionButton: FloatingActionButton(
              backgroundColor: Colors.white,
              onPressed: () => _openAddTaskForm(context),
              child: const Icon(Icons.add, color: Color(0xFFB200B2)),
              tooltip: 'Add Task',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserDrawer(BuildContext context) {
    final user = AuthService.currentUser;
    return Drawer(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.35),
            border: Border.all(color: Colors.white, width: 3),
          ),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundImage: user?.photoURL != null
                            ? NetworkImage(user!.photoURL!)
                            : null,
                        child: user?.photoURL == null
                            ? Icon(Icons.person, size: 30)
                            : null,
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              user?.displayName ?? 'User',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepPurple,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              user?.email ?? 'Email',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 32),
                ListTile(
                  leading: Icon(Icons.dashboard, color: Colors.deepPurple),
                  title: Text(
                    "Dashboard",
                    style: TextStyle(color: Colors.deepPurple),
                  ),
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => DashboardScreen(),
                      ),
                    );
                  },
                ),
                ListTile(
                  leading: Icon(Icons.logout, color: Colors.red),
                  title: Text("Logout", style: TextStyle(color: Colors.red)),
                  onTap: () async {
                    final user = AuthService.currentUser;
                    await AuthService.signOut();
                    if (user != null) {
                      await LocalNotificationService.showLogoutNotification(
                        user.displayName ?? 'User',
                      );
                    }
                    // You can add a redirect to login screen here
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MainScreenFilterDropdown extends StatelessWidget {
  final TaskFilter filter;
  final ValueChanged<TaskFilter?>? onChanged;
  const _MainScreenFilterDropdown({
    Key? key,
    required this.filter,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final filterOptions = [
      {'label': 'My Tasks', 'filter': TaskFilter.all, 'icon': Icons.task},
      {
        'label': 'Completed',
        'filter': TaskFilter.done,
        'icon': Icons.check_circle,
      },
      {
        'label': 'Overdue',
        'filter': TaskFilter.overdue,
        'icon': Icons.warning_amber_rounded,
      },
      {'label': 'Today', 'filter': TaskFilter.today, 'icon': Icons.wb_sunny},
    ];
    final selected = filterOptions.firstWhere((opt) => opt['filter'] == filter);
    return DropdownButtonHideUnderline(
      child: DropdownButton<TaskFilter>(
        value: filter,
        icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
        dropdownColor: Colors.white.withOpacity(0.95),
        style: const TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
        borderRadius: BorderRadius.circular(18),
        onChanged: onChanged,
        selectedItemBuilder: (context) => filterOptions.map((opt) {
          return Row(
            children: [
              Icon(opt['icon'] as IconData, color: Colors.white, size: 22),
              const SizedBox(width: 8),
              Text(
                opt['label'] as String,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          );
        }).toList(),
        items: filterOptions.map((opt) {
          return DropdownMenuItem<TaskFilter>(
            value: opt['filter'] as TaskFilter,
            child: Row(
              children: [
                Icon(opt['icon'] as IconData, color: Colors.black, size: 22),
                const SizedBox(width: 8),
                Text(
                  opt['label'] as String,
                  style: const TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}
