import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'task_model.dart';

class AddTaskForm extends StatefulWidget {
  final void Function(
    String title,
    String description,
    DateTime dueDate,
    TaskPriority priority,
  )
  onSave;

  const AddTaskForm({Key? key, required this.onSave}) : super(key: key);

  @override
  State<AddTaskForm> createState() => _AddTaskFormState();
}

class _AddTaskFormState extends State<AddTaskForm> {
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  DateTime? _selectedDate;
  TaskPriority _priority = TaskPriority.medium;

  void _submitForm() {
    if (_titleController.text.trim().isEmpty || _selectedDate == null) return;

    widget.onSave(
      _titleController.text.trim(),
      _descController.text.trim(),
      _selectedDate!,
      _priority,
    );
    Navigator.of(context).pop();
  }

  void _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now.subtract(Duration(days: 1)),
      lastDate: now.add(Duration(days: 365)),
    );

    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Color _getPriorityColor(TaskPriority priority) {
    switch (priority) {
      case TaskPriority.low:
        return Colors.green;
      case TaskPriority.medium:
        return Colors.orange;
      case TaskPriority.high:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    final formatter = DateFormat.yMMMd();

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _titleController,
            decoration: InputDecoration(labelText: 'Task Title'),
          ),
          TextField(
            controller: _descController,
            decoration: InputDecoration(labelText: 'Description'),
            maxLines: 2,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                _selectedDate == null
                    ? 'No date chosen!'
                    : 'Due: ${formatter.format(_selectedDate!)}',
              ),
              Spacer(),
              TextButton.icon(
                icon: Icon(Icons.calendar_today),
                label: Text('Pick Date'),
                onPressed: _pickDate,
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Priority Selection
          Row(
            children: [
              Text('Priority: '),
              const SizedBox(width: 8),
              ...TaskPriority.values.map((priority) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(
                      priority.toString().split('.').last.toUpperCase(),
                      style: TextStyle(
                        color: _priority == priority
                            ? Colors.white
                            : _getPriorityColor(priority),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    selected: _priority == priority,
                    selectedColor: _getPriorityColor(priority),
                    backgroundColor: Colors.grey[200],
                    onSelected: (selected) {
                      if (selected) {
                        setState(() {
                          _priority = priority;
                        });
                      }
                    },
                  ),
                );
              }).toList(),
            ],
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            onPressed: _submitForm,
            icon: Icon(Icons.save),
            label: Text('Save Task'),
          ),
        ],
      ),
    );
  }
}
