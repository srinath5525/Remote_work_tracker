import 'package:flutter/material.dart';

class StopwatchController extends ChangeNotifier {
  Duration elapsed = Duration.zero;
  bool isRunning = false;
  late Ticker _ticker;
  List<Duration> intervals = [];
  bool _disposed = false;

  StopwatchController() {
    _ticker = Ticker(_onTick);
  }

  void _onTick(Duration delta) {
    if (isRunning && !_disposed) {
      elapsed += delta;
      notifyListeners();
    }
  }

  void start() {
    if (!isRunning && !_disposed) {
      isRunning = true;
      _ticker.start();
      notifyListeners();
    }
  }

  void pause() {
    if (isRunning && !_disposed) {
      isRunning = false;
      _ticker.stop();
      notifyListeners();
    }
  }

  void reset() {
    if (!_disposed) {
      isRunning = false;
      _ticker.stop();
      elapsed = Duration.zero;
      intervals.clear();
      notifyListeners();
    }
  }

  void addInterval() {
    if (!_disposed) {
      intervals.add(elapsed);
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    _ticker.dispose();
    super.dispose();
  }
}

class StopwatchModal extends StatefulWidget {
  final String taskTitle;
  const StopwatchModal({Key? key, required this.taskTitle}) : super(key: key);

  @override
  State<StopwatchModal> createState() => _StopwatchModalState();
}

class _StopwatchModalState extends State<StopwatchModal>
    with SingleTickerProviderStateMixin {
  late StopwatchController controller;

  @override
  void initState() {
    super.initState();
    controller = StopwatchController();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  String _format(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    final ms = (d.inMilliseconds % 1000 ~/ 10).toString().padLeft(2, '0');
    return '$m:$s.$ms';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(widget.taskTitle, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 16),
          AnimatedBuilder(
            animation: controller,
            builder: (context, _) => Text(
              _format(controller.elapsed),
              style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Start button
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFE6E6FA),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  iconSize: 32,
                  icon: const Icon(Icons.play_arrow, color: Colors.deepPurple),
                  onPressed: controller.isRunning
                      ? null
                      : () {
                          setState(() {
                            controller.start();
                          });
                        },
                  tooltip: 'Start',
                ),
              ),
              // Stop button
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFE6E6FA),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  iconSize: 32,
                  icon: const Icon(Icons.stop, color: Colors.deepPurple),
                  onPressed: controller.isRunning
                      ? () {
                          setState(() {
                            controller.pause();
                          });
                        }
                      : null,
                  tooltip: 'Stop',
                ),
              ),
              // Reset button
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFE6E6FA),
                  shape: BoxShape.circle,
                ),
                child: IconButton(
                  iconSize: 32,
                  icon: const Icon(Icons.refresh, color: Colors.deepPurple),
                  onPressed: controller.elapsed > Duration.zero
                      ? () {
                          setState(() {
                            controller.reset();
                          });
                        }
                      : null,
                  tooltip: 'Reset',
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

Future<void> showStopwatchForTask(
  BuildContext context,
  String taskTitle,
) async {
  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (_) => StopwatchModal(taskTitle: taskTitle),
  );
}

class Ticker {
  final void Function(Duration) onTick;
  late final TickerFuture _tickerFuture;
  bool _running = false;
  Duration _lastElapsed = Duration.zero;
  Ticker(this.onTick);
  void start() {
    _running = true;
    _lastElapsed = Duration(
      milliseconds: DateTime.now().millisecondsSinceEpoch,
    );
    _tick();
  }

  void stop() {
    _running = false;
  }

  void _tick() async {
    while (_running) {
      await Future.delayed(const Duration(milliseconds: 30));
      final now = Duration(milliseconds: DateTime.now().millisecondsSinceEpoch);
      final delta = now - _lastElapsed;
      _lastElapsed = now;
      onTick(delta);
    }
  }

  void dispose() {
    _running = false;
  }
}
