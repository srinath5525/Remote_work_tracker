import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive/hive.dart';

part 'task_model.g.dart';

@HiveType(typeId: 0)
enum TaskPriority {
  @HiveField(0)
  low,
  @HiveField(1)
  medium,
  @HiveField(2)
  high,
}

@HiveType(typeId: 1)
class TaskModel extends HiveObject {
  @HiveField(0)
  final String id;

  @HiveField(1)
  final String title;

  @HiveField(2)
  final String description;

  @HiveField(3)
  final DateTime dueDate;

  @HiveField(4)
  final bool isDone;

  @HiveField(5)
  final bool hasTimer;

  @HiveField(6)
  final DateTime? completedAt;

  @HiveField(7)
  final TaskPriority priority;

  TaskModel({
    required this.id,
    required this.title,
    required this.description,
    required this.dueDate,
    this.isDone = false,
    this.hasTimer = false,
    this.completedAt,
    this.priority = TaskPriority.medium,
  });

  /// Factory constructor to create TaskModel from Firestore
  factory TaskModel.fromMap(Map<String, dynamic> data, String docId) {
    return TaskModel(
      id: docId,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      dueDate: (data['dueDate'] as Timestamp).toDate(),
      isDone: data['isDone'] ?? false,
      hasTimer: data['hasTimer'] ?? false,
      completedAt: data['completedAt'] != null
          ? (data['completedAt'] as Timestamp).toDate()
          : null,
      priority: TaskPriority.values.firstWhere(
        (p) => p.toString().split('.').last == (data['priority'] ?? 'medium'),
        orElse: () => TaskPriority.medium,
      ),
    );
  }

  /// Convert to map for uploading to Firestore
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'dueDate': dueDate,
      'isDone': isDone,
      'hasTimer': hasTimer,
      'priority': priority.toString().split('.').last,
      if (completedAt != null) 'completedAt': completedAt,
    };
  }

  /// CopyWith method for immutability
  TaskModel copyWith({
    String? id,
    String? title,
    String? description,
    DateTime? dueDate,
    bool? isDone,
    bool? hasTimer,
    DateTime? completedAt,
    TaskPriority? priority,
  }) {
    return TaskModel(
      id: id ?? this.id,
      title: title ?? this.title,
      description: description ?? this.description,
      dueDate: dueDate ?? this.dueDate,
      isDone: isDone ?? this.isDone,
      hasTimer: hasTimer ?? this.hasTimer,
      completedAt: completedAt ?? this.completedAt,
      priority: priority ?? this.priority,
    );
  }

  @override
  String toString() {
    return 'TaskModel(title: $title, dueDate: $dueDate, isDone: $isDone, priority: $priority)';
  }
}
