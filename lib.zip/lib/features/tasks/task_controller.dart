import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import '../../auth_service.dart';
import '../../core/services/local_notification_service.dart';
import 'package:permission_handler/permission_handler.dart';
import 'task_model.dart';

class TaskController {
  static const String _tasksBoxName = 'tasks_cache';
  static const String _pendingSyncBoxName = 'pending_sync';

  static Box<TaskModel>? _tasksBox;
  static Box<Map>? _pendingSyncBox;
  static bool _isOnline = true;

  // Initialize boxes
  static Future<void> initialize() async {
    _tasksBox = await Hive.openBox<TaskModel>(_tasksBoxName);
    _pendingSyncBox = await Hive.openBox<Map>(_pendingSyncBoxName);

    // Monitor connectivity
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      _isOnline = result != ConnectivityResult.none;
      print("🌐 Network status: ${_isOnline ? 'Online' : 'Offline'}");

      if (_isOnline) {
        _syncPendingChanges();
      }
    });

    // Check initial connectivity
    final connectivityResult = await Connectivity().checkConnectivity();
    _isOnline = connectivityResult != ConnectivityResult.none;
  }

  static CollectionReference<Map<String, dynamic>> _userTasksCollection(
    String uid,
  ) {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('tasks');
  }

  // Get tasks from local cache first, then sync with Firestore if online
  static Stream<List<TaskModel>> getTasks() {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return const Stream.empty();

    // Start with local data
    final localTasks = _getLocalTasks();

    if (!_isOnline) {
      // Return local data only when offline
      return Stream.value(localTasks);
    }

    // When online, listen to Firestore and update local cache
    return _userTasksCollection(uid).snapshots().map((snap) {
      final firestoreTasks = snap.docs
          .map((doc) => TaskModel.fromMap(doc.data(), doc.id))
          .toList();

      // Update local cache
      _updateLocalCache(firestoreTasks);

      return firestoreTasks;
    });
  }

  // Add task to local cache and Firestore (if online)
  static Future<void> addTask(TaskModel task) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;

    // Always add to local cache first
    await _addToLocalCache(task);
    print("💾 Task '${task.title}' saved locally");

    // Request permission before scheduling notifications (Android 12+)
    if (await Permission.scheduleExactAlarm.isDenied) {
      await Permission.scheduleExactAlarm.request();
    }

    // Schedule notifications 5 hours before the deadline, every 30 minutes
    await LocalNotificationService.scheduleRepeatingDeadlineNotifications(
      id: task.id.hashCode,
      taskTitle: task.title,
      deadline: task.dueDate,
    );

    if (_isOnline) {
      // Add to Firestore if online
      try {
        await _userTasksCollection(uid).doc(task.id).set(task.toMap());
        print("☁️ Task '${task.title}' synced to Firestore");
      } catch (e) {
        print("❌ Failed to sync task to Firestore: $e");
        await _addToPendingSync('add', task);
      }
    } else {
      // Add to pending sync if offline
      await _addToPendingSync('add', task);
      print("📱 Task '${task.title}' queued for sync when online");
    }
  }

  // Update task in local cache and Firestore (if online)
  static Future<void> updateTask(TaskModel task) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;

    try {
      // If marking as done, set completedAt to now. If marking as not done, set completedAt to null.
      final updatedTask = task.isDone
          ? task.copyWith(completedAt: task.completedAt ?? DateTime.now())
          : task.copyWith(completedAt: null);

      // Always update local cache first
      await _updateLocalTask(updatedTask);
      print("💾 Task '${task.title}' updated locally");

      if (_isOnline) {
        // Update Firestore if online
        await _userTasksCollection(
          uid,
        ).doc(task.id).update(updatedTask.toMap());
        print("☁️ Task '${task.title}' synced to Firestore");
      } else {
        // Add to pending sync if offline
        await _addToPendingSync('update', updatedTask);
        print("📱 Task '${task.title}' queued for sync when online");
      }
    } catch (e) {
      print("❌ Failed to update task: $e");
    }
  }

  // Delete task from local cache and Firestore (if online)
  static Future<void> deleteTask(String id) async {
    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;

    // Always delete from local cache first
    await _deleteFromLocalCache(id);
    print("💾 Task deleted locally");

    if (_isOnline) {
      // Delete from Firestore if online
      try {
        await _userTasksCollection(uid).doc(id).delete();
        print("☁️ Task deleted from Firestore");
      } catch (e) {
        print("❌ Failed to delete task from Firestore: $e");
        await _addToPendingSync('delete', null, taskId: id);
      }
    } else {
      // Add to pending sync if offline
      await _addToPendingSync('delete', null, taskId: id);
      print("📱 Task deletion queued for sync when online");
    }
  }

  // Local cache methods
  static List<TaskModel> _getLocalTasks() {
    if (_tasksBox == null) return [];
    return _tasksBox!.values.toList();
  }

  static Future<void> _addToLocalCache(TaskModel task) async {
    if (_tasksBox == null) return;
    await _tasksBox!.put(task.id, task);
  }

  static Future<void> _updateLocalTask(TaskModel task) async {
    if (_tasksBox == null) return;
    await _tasksBox!.put(task.id, task);
  }

  static Future<void> _deleteFromLocalCache(String id) async {
    if (_tasksBox == null) return;
    await _tasksBox!.delete(id);
  }

  static Future<void> _updateLocalCache(List<TaskModel> tasks) async {
    if (_tasksBox == null) return;
    await _tasksBox!.clear();
    for (final task in tasks) {
      await _tasksBox!.put(task.id, task);
    }
  }

  // Pending sync methods
  static Future<void> _addToPendingSync(
    String action,
    TaskModel? task, {
    String? taskId,
  }) async {
    if (_pendingSyncBox == null) return;

    final syncItem = {
      'action': action,
      'task': task?.toMap(),
      'taskId': taskId ?? task?.id,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
    };

    await _pendingSyncBox!.add(syncItem);
  }

  // Sync pending changes when coming back online
  static Future<void> _syncPendingChanges() async {
    if (_pendingSyncBox == null || _pendingSyncBox!.isEmpty) return;

    final uid = AuthService.currentUser?.uid;
    if (uid == null) return;

    print("🔄 Syncing pending changes...");

    final pendingItems = _pendingSyncBox!.values.toList();

    for (final item in pendingItems) {
      try {
        final action = item['action'] as String;
        final taskData = item['task'] as Map<String, dynamic>?;
        final taskId = item['taskId'] as String?;

        switch (action) {
          case 'add':
            if (taskData != null) {
              final task = TaskModel.fromMap(taskData, taskId!);
              await _userTasksCollection(uid).doc(task.id).set(task.toMap());
              print("✅ Synced added task: ${task.title}");
            }
            break;
          case 'update':
            if (taskData != null) {
              final task = TaskModel.fromMap(taskData, taskId!);
              await _userTasksCollection(uid).doc(task.id).update(task.toMap());
              print("✅ Synced updated task: ${task.title}");
            }
            break;
          case 'delete':
            if (taskId != null) {
              await _userTasksCollection(uid).doc(taskId).delete();
              print("✅ Synced deleted task: $taskId");
            }
            break;
        }
      } catch (e) {
        print("❌ Failed to sync item: $e");
      }
    }

    // Clear pending sync after successful sync
    await _pendingSyncBox!.clear();
    print("✅ All pending changes synced");
  }

  // Get offline status
  static bool get isOffline => !_isOnline;

  // Get pending sync count
  static int get pendingSyncCount => _pendingSyncBox?.length ?? 0;
}
