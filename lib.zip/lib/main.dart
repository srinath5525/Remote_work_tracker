import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'auth_gate.dart';
import 'core/services/local_notification_service.dart';
import 'features/tasks/task_model.dart';
import 'features/tasks/task_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize Hive for local storage
  await Hive.initFlutter();

  // Register Hive adapters
  Hive.registerAdapter(TaskPriorityAdapter());
  Hive.registerAdapter(TaskModelAdapter());

  await Hive.openBox('tasks_cache');
  await Hive.openBox('user_session');
  print("✅ Hive initialized");

  // Initialize Firebase
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  print("✅ Firebase initialized");

  // Enable Firestore offline persistence
  FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true,
    cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
  );
  print("✅ Firestore offline persistence enabled");

  // Initialize TaskController for offline caching
  await TaskController.initialize();
  print("✅ TaskController initialized");

  await LocalNotificationService.initialize();
  await LocalNotificationService.scheduleHealthReminders();

  FirebaseAuth.instance.authStateChanges().listen((user) {
    print("👤 User state changed: $user");
    if (user != null) {
      LocalNotificationService.showLoginNotification(
        user.displayName ?? 'User',
      );
    }
  });

  runApp(const RemoteWorkTrackerApp());
}

class RemoteWorkTrackerApp extends StatelessWidget {
  const RemoteWorkTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Remote Work Tracker',
      theme: ThemeData(useMaterial3: true, primarySwatch: Colors.blue),
      home: const AuthGate(),
    );
  }
}
